# Local examples

curl -o html.pdf -XPOST -d@test/resources/large-linked.html -H"content-type: text/html" https://url-to-pdf-api.herokuapp.com/api/render