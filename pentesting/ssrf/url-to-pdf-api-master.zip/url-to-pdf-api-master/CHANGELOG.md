# CHANGELOG

* change the `:html` output to return `document.documentElement.innerHTML` instead of previously used `document.body.innerHTML`

## 1.0.0

* initial version
