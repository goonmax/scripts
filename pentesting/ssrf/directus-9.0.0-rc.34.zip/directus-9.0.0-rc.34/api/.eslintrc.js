const parentConfig = require('../.eslintrc.js');

module.exports = {
	...parentConfig,
};
