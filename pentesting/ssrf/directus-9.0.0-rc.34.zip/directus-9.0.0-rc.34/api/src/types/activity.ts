export enum Action {
	CREATE = 'create',
	UPDATE = 'update',
	DELETE = 'delete',
	REVERT = 'revert',
	COMMENT = 'comment',
	UPLOAD = 'upload',
	AUTHENTICATE = 'authenticate',
}
