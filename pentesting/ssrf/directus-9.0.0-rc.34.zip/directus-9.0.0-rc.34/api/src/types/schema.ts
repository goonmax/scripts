import { SchemaOverview as SO } from '@directus/schema/dist/types/overview';

export type SchemaOverview = SO;
