const parentConfig = require('../.prettierrc.js');

module.exports = {
	...parentConfig,
};
