#!/usr/bin/env node
return require('./dist/cli/index.js');
