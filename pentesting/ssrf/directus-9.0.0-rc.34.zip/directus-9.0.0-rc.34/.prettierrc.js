module.exports = {
	htmlWhitespaceSensitivity: 'ignore',
	printWidth: 120,
	singleQuote: true,
	useTabs: true,
	proseWrap: 'always',
};
