export default function withBackground() {
	return {
		template: `<div class="alt-colors" style="height: 100%; background-color: var(--background-color);"><story /></div>`
	}
}
