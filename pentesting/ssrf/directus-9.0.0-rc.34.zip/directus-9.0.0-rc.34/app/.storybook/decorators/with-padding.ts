export default function withPadding() {
	return {
		template: `<div style="padding: 24px; height: 100%;"><story /></div>`
	}
}
