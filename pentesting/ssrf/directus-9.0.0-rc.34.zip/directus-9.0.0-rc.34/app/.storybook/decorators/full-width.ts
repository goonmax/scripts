export default function fullWidth() {
	return {
		template: `<div style="max-width: 632px;"><story /></div>`,
	};
}
