export default function halfWidth() {
	return {
		template: `<div style="max-width: 300px;"><story /></div>`,
	};
}
