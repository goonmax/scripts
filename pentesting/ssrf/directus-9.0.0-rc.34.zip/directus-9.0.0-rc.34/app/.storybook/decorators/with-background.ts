export default function withBackground() {
	return {
		template: `<div style="background-color: #dde3e6; height: 100%;"><story /></div>`
	}
}
