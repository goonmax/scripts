# Assets

Static assets that are used in the app. Primarily used for logos and fonts.
