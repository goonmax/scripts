import VHover from './v-hover.vue';

export { VHover };
export default VHover;
