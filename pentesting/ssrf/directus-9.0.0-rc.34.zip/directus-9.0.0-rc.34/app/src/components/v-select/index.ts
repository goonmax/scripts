import VSelect from './v-select.vue';

export { VSelect };
export default VSelect;
