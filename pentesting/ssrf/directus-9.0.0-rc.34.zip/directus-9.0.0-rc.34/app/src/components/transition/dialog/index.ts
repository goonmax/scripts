import TransitionDialog from './transition-dialog.vue';

export { TransitionDialog };
export default TransitionDialog;
