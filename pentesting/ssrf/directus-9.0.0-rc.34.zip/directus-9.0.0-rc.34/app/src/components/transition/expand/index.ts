import TransitionExpand from './transition-expand.vue';

export { TransitionExpand };
export default TransitionExpand;
