import TransitionBounce from './transition-bounce.vue';

export { TransitionBounce };
export default TransitionBounce;
