# Transitions

Preset extensions of the Vue `transition` element.

## Table of Contents

-   [`Expand`](./expand)
