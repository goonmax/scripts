import VFancySelect from './v-fancy-select.vue';

export { VFancySelect };
export default VFancySelect;
