import VMenu from './v-menu.vue';

export { VMenu };
export default VMenu;
