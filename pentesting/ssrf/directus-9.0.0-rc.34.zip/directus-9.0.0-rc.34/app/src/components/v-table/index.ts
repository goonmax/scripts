import VTable from './v-table.vue';

export { VTable };
export default VTable;
