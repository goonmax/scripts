import TableHeader from './table-header.vue';

export { TableHeader };
export default TableHeader;
