import TableRow from './table-row.vue';

export { TableRow };
export default TableRow;
