import VFieldTemplate from './v-field-template.vue';

export default VFieldTemplate;
export { VFieldTemplate };
