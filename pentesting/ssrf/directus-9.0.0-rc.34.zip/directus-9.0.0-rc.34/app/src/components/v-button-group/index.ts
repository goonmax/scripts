import VButtonGroup from './v-button-group.vue';

export { VButtonGroup };
export default VButtonGroup;
