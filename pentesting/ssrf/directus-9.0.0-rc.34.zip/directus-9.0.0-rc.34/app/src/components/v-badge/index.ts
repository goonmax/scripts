import VBadge from './v-badge.vue';

export { VBadge };
export default VBadge;
