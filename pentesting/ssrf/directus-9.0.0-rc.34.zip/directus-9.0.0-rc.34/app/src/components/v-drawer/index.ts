import VDrawer from './v-drawer.vue';

export { VDrawer };
export default VDrawer;
