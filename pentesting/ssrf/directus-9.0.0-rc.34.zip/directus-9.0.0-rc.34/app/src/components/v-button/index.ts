import VButton from './v-button.vue';

export { VButton };
export default VButton;
