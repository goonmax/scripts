import VAvatar from './v-avatar.vue';

export { VAvatar };
export default VAvatar;
