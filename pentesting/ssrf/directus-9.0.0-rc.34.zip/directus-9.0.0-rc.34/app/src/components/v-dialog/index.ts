import VDialog from './v-dialog.vue';

export { VDialog };
export default VDialog;
