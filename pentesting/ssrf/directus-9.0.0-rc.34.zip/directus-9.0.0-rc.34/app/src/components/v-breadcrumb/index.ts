import VBreadcrumb from './v-breadcrumb.vue';

export { VBreadcrumb };
export default VBreadcrumb;
