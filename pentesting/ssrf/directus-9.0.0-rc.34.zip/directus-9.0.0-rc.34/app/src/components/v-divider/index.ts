import VDivider from './v-divider.vue';

export { VDivider };
export default VDivider;
