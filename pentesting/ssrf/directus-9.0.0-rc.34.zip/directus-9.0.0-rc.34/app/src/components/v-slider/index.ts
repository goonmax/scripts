import VSlider from './v-slider.vue';

export { VSlider };
export default VSlider;
