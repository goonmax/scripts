import VPagination from './v-pagination.vue';

export { VPagination };
export default VPagination;
