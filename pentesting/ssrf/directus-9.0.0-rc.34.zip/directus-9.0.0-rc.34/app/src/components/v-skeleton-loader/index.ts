import VSkeletonLoader from './v-skeleton-loader.vue';

export { VSkeletonLoader };
export default VSkeletonLoader;
