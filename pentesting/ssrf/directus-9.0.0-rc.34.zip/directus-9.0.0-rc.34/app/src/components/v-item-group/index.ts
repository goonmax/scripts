import VItemGroup from './v-item-group.vue';
import VItem from './v-item.vue';

export { VItemGroup, VItem };
export default VItemGroup;
