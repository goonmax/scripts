import VSwitch from './v-switch.vue';

export { VSwitch };
export default VSwitch;
