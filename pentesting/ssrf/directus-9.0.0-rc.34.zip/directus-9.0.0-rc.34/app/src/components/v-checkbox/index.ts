import VCheckbox from './v-checkbox.vue';

export { VCheckbox };
export default VCheckbox;
