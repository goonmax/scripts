import VInfo from './v-info.vue';

export { VInfo };
export default VInfo;
