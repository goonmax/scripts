<template functional>
	<svg
		viewBox="0 0 48 48"
		xmlns="http://www.w3.org/2000/svg"
		fill-rule="evenodd"
		clip-rule="evenodd"
		stroke-linejoin="round"
		stroke-miterlimit="2"
	>
		<path
			fill-opacity=".3"
			d="M24.02 42.98L47.28 14c-.9-.68-9.85-8-23.28-8S1.62 13.32.72 14l23.26 28.98.02.02.02-.02z"
		/>
		<path d="M0 0h48v48H0z" fill="none" />
		<path
			d="M13.34 29.72l10.65 13.27.01.01.01-.01 10.65-13.27C34.13 29.31 30.06 26 24 26s-10.13 3.31-10.66 3.72z"
		/>
	</svg>
</template>

<script lang="ts">
export default {};
</script>
