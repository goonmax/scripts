import VIcon from './v-icon.vue';

export { VIcon };
export default VIcon;
