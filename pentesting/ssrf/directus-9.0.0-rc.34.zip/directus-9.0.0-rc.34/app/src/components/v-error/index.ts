import VError from './v-error.vue';

export default VError;
export { VError };
