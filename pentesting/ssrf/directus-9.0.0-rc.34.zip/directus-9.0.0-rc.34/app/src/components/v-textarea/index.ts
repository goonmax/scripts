import VTextarea from './v-textarea.vue';

export { VTextarea };
export default VTextarea;
