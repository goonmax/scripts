import VTabItem from './v-tab-item.vue';

export { VTabItem };
export default VTabItem;
