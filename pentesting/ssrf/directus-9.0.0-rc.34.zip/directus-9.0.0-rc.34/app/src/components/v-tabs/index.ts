import VTabs from './v-tabs.vue';
import VTab from './v-tab/';
import VTabsItems from './v-tabs-items/';
import VTabItem from './v-tab-item/';

export { VTabs, VTab, VTabsItems, VTabItem };
export default VTabs;
