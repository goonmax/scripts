import VTabsItems from './v-tabs-items.vue';

export { VTabsItems };
export default VTabsItems;
