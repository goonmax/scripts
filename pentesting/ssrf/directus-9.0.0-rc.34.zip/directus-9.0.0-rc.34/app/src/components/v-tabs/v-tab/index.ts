import VTab from './v-tab.vue';

export { VTab };
export default VTab;
