import VProgressCircular from './v-progress-circular.vue';

export { VProgressCircular };
export default VProgressCircular;
