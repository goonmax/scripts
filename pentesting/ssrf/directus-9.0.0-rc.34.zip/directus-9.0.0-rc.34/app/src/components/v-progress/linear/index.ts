import VProgressLinear from './v-progress-linear.vue';

export { VProgressLinear };
export default VProgressLinear;
