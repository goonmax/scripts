import VRadio from './v-radio.vue';

export { VRadio };
export default VRadio;
