import VNotice from './v-notice.vue';

export { VNotice };
export default VNotice;
