import VChip from './v-chip.vue';

export { VChip };
export default VChip;
