import VFieldSelect from './v-field-select.vue';

export default VFieldSelect;
export { VFieldSelect };
