import VDetail from './v-detail.vue';

export { VDetail };
export default VDetail;
