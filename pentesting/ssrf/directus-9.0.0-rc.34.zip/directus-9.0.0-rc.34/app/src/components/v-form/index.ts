import VForm from './v-form.vue';

export { VForm };
export default VForm;
