import VUpload from './v-upload.vue';

export { VUpload };
export default VUpload;
