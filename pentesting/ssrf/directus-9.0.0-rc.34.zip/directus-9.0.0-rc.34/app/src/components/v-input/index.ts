import VInput from './v-input.vue';

export { VInput };
export default VInput;
