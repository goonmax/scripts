import VOverlay from './v-overlay.vue';

export { VOverlay };
export default VOverlay;
