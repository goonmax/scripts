import useEventListener from './use-event-listener';

export { useEventListener };
export default useEventListener;
