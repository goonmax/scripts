import useScrollDistance from './use-scroll-distance';

export { useScrollDistance };
export default useScrollDistance;
