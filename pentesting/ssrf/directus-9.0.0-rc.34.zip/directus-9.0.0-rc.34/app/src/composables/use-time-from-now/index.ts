import { useTimeFromNow } from './use-time-from-now';

export { useTimeFromNow };
export default useTimeFromNow;
