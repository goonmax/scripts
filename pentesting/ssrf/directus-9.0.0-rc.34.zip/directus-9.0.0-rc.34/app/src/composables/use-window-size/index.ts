import useWindowSize from './use-window-size';

export { useWindowSize };
export default useWindowSize;
