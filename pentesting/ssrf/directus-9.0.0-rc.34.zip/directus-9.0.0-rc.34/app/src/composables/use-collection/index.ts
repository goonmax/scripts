import { useCollection } from './use-collection';

export { useCollection };
export default useCollection;
