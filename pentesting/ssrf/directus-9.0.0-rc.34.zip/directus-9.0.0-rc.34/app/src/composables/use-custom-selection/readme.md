# useCustomSelection

This is a very specific composition meant to be used in v-select and the radios / checkboxes interfaces.

It's the logic that keeps track of custom options in a selection module, like the custom values in a
multi-select dropdown.

```ts
useCustomSelection()
```

