import { useCustomSelection, useCustomSelectionMultiple } from './use-custom-selection';

export { useCustomSelection, useCustomSelectionMultiple };
export default { useCustomSelection, useCustomSelectionMultiple };
