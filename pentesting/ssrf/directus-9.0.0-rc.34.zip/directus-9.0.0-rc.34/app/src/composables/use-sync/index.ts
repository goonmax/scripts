import useSync from './use-sync';

export { useSync };
export default useSync;
