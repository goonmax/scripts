import useSizeClass, { sizeProps } from './size-class';

export { sizeProps, useSizeClass };
export default useSizeClass;
