import useShortcut from './use-shortcut';

export { useShortcut };
export default useShortcut;
