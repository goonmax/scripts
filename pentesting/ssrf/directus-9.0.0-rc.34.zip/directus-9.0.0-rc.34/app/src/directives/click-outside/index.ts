import ClickOutside from './click-outside';

export { ClickOutside };
export default ClickOutside;
