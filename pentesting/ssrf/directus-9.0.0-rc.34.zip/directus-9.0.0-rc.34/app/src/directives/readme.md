# Directives

Directives are functions that are available on Vue components in templates. For example `v-focus` or `v-tooltip="'Hello world!'`
