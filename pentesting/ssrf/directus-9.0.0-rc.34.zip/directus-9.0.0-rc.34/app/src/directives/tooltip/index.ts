import Tooltip from './tooltip';

export { Tooltip };
export default Tooltip;
